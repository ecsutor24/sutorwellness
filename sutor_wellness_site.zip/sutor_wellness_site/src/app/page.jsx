import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Dumbbell, BookOpenCheck, ShoppingCart } from "lucide-react";

export default function Home() {
  return (
    <main className="p-6 max-w-7xl mx-auto">
      <section className="text-center py-10">
        <h1 className="text-4xl font-bold mb-4">Sutor Wellness Solutions LLC</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Helping busy parents and professionals improve their physical, mental,
          and emotional wellness through practical strategies, personalized plans,
          and supportive tools.
        </p>
        <Button className="mt-6 text-lg px-6 py-3">Get Started</Button>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
        <Card>
          <CardContent className="p-6 text-center">
            <Dumbbell className="mx-auto mb-4 h-8 w-8" />
            <h2 className="text-xl font-semibold mb-2">Custom Workout Plans</h2>
            <p className="text-gray-600 text-sm">
              Tailored fitness routines for your lifestyle, goals, and available equipment.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <BookOpenCheck className="mx-auto mb-4 h-8 w-8" />
            <h2 className="text-xl font-semibold mb-2">Wellness Trackers & Journals</h2>
            <p className="text-gray-600 text-sm">
              Branded digital PDFs to track workouts, meals, habits, hydration, and sleep.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <ShoppingCart className="mx-auto mb-4 h-8 w-8" />
            <h2 className="text-xl font-semibold mb-2">Digital Store</h2>
            <p className="text-gray-600 text-sm">
              Access our Etsy shop for downloadable wellness resources.
            </p>
          </CardContent>
        </Card>
      </section>

      <section className="mt-20 text-center">
        <h2 className="text-2xl font-bold mb-4">Have Questions?</h2>
        <p className="text-gray-600 mb-6">Reach out to learn more or book a free consultation.</p>
        <Button variant="outline" className="flex items-center gap-2 mx-auto">
          <Mail className="w-4 h-4" /> Contact Us
        </Button>
      </section>
    </main>
  );
}